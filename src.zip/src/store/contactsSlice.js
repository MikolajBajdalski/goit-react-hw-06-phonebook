import { createSlice } from '@reduxjs/toolkit';

export const contactsSlice = createSlice({
  name: 'contacts',
  initialState: [],
  reducers: {
    addContact: (state, action) => {
      // Logika dodawania kontaktu
    },
    deleteContact: (state, action) => {
      // Logika usuwania kontaktu
    },
    // Możesz dodać więcej akcji w razie potrzeby
  },
});

export const { addContact, deleteContact } = contactsSlice.actions;
export default contactsSlice.reducer;
